# Railway PRE-APK Audit — 2026-09-23

Bu belge read-only Railway kontrolünün redakte özetidir; secret değerleri içermez.

- Project: `BorsaTakipV5-Backend`
- Production service checked: `borsa-takip-v5416-final`
- Public domain: `borsa-takip-v5416-final-production.up.railway.app`
- Latest deployment observed: SUCCESS
- Source observed by Railway: `dilekari-droid/BorsaTakipV5-Production`, branch `main`, commit `b9aa3be097e8a49ee43085a0a20a2e4f4930eda2`, root `backend`
- Variable names observed on final service: `APP_API_KEY`, `APP_ENV`, `BACKEND_RUNTIME_VERSION`, `SESSION_TOKEN_SECRET` plus Railway-provided variables.
- No `TRADEWIZE_API_KEY` or `TRADEWIZE_ACCESS_TOKEN` variable name was observed on that service during this audit.
- Existing Railway E2E runner's latest observed attempt failed at `preflight did not provide sampleSymbol`.

Sonuç: source code provider credential olmadan production startup'ı fail-closed yapacak şekilde sertleştirilmiştir; fakat mevcut external deployment secret/source revision durumu ayrıca düzeltilmeden production provider E2E PASS kabul edilmemelidir. Bu audit sırasında Railway secret/deployment mutation yapılmadı.
